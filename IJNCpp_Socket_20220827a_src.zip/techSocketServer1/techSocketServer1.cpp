﻿// techSocketServer1.cpp : 此檔案包含 'main' 函式。程式會於該處開始執行及結束執行。
//

#include <iostream>
#include "../IJNCpp/easyWinSock2.hpp"

int main()
{
	try
	{
		IJN::easyWSAStartup();
		auto socket = IJN::SocketForServerGenerator().main(1234);
		while (true) {
			std::cout << " 等待中 ... port:1234 \n"; 
			auto client = IJN::easyAccept(socket);

			std::string buf = "0123456789";
			send(client, buf.c_str(), 10, 0);

			IJN::easyShutdown(client);
			closesocket(client);
			std::cout << " 關閉連線，重新等待 ...\n";
		}
	}
	catch (const std::exception& ex)
	{
		std::cout << "error: " << ex.what() << "\n";
		system("pause");
	}
}
