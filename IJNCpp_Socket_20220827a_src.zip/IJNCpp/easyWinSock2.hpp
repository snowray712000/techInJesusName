#pragma once

#pragma once
#include <cassert>
#include <sstream>

#include <WinSock2.h>
#include <WS2tcpip.h> // getaddrinfo
#pragma comment(lib,"Ws2_32.lib")
namespace IJN {
	// �ϥήɡA�i�����j�ର int 
	enum class easyAI_FAMILY {
		UNSPEC = AF_UNSPEC,
		INET = AF_INET,
		INET6 = AF_INET6,
	};
	// WSAGetLastError �|�^�ǰ�����̫�@�ӿ��~�A�o�Ө禡�O���U��^�Ǫ� idError �ର String�C
	inline std::string cvtWSALastErrorToString(int idWSAGetLastError) {
		char msgbuf[256];
		msgbuf[0] = '\0';
		FormatMessageA(FORMAT_MESSAGE_FROM_SYSTEM | FORMAT_MESSAGE_IGNORE_INSERTS,
			NULL,
			idWSAGetLastError,
			MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
			msgbuf,
			sizeof(msgbuf),
			NULL);
		return msgbuf;
	}
	// "xxxxx idError: oo stringError: ppppp"
	inline std::string easyGetWSALastErrorString(std::string prefix) {
		auto id = WSAGetLastError();
		std::stringstream ss;
		ss << prefix << " idError: " << id << " stringError: " << cvtWSALastErrorToString(id);
		return ss.str();
	}
	// �۹������O WSACleanup ()
	inline void easyWSAStartup() {
		WSADATA wsaData;
		WORD version = MAKEWORD(2, 2);

		// Initialize Winsock
		auto iResult = WSAStartup(version, &wsaData);
		if (iResult != 0) {
			auto r1 = easyGetWSALastErrorString("WSAStartup failed.");
			throw std::exception(r1.c_str());
		}
	}
	// g: generate �Φb easyGetAddrinfo �� hints �Ѽ�
	inline struct addrinfo gAddrinfo(bool isServerNotClient = true) {
		struct addrinfo hints = { 0 };
		if (isServerNotClient) {
			hints.ai_family = (int)easyAI_FAMILY::INET;
			hints.ai_flags = AI_PASSIVE;
		} else {
			hints.ai_family = (int)easyAI_FAMILY::UNSPEC;
		}
		hints.ai_socktype = SOCK_STREAM;
		hints.ai_protocol = IPPROTO_TCP;
		return hints;
	}

	// �� client �Ϊ��C
	// �n�� freeaddrinfo�C�_�h�|�y���O����ݯd�C
	// freeaddrinfo �O���n���A�]�� getaddrinfo �� result �O�� list�A�ӫD�@�w�O 1 �ӭȡC
	inline addrinfo* easyGetAddrInfo(std::string dst, int port, const addrinfo* hints) {
		char buf[32];
		sprintf_s(buf, 32, "%d", port);
		PCSTR DEFAULT_PORT = buf;

		auto nodeName = dst.empty() ? nullptr : dst.c_str();

		// Resolve the server address and port
		addrinfo* result = nullptr;
		auto iResult = getaddrinfo(nodeName, DEFAULT_PORT, hints, &result);
		if (iResult != 0) {
			auto err = easyGetWSALastErrorString("getaddrinfo failed.");
			throw std::exception(err.c_str());
		}
		return result;
	}
	// �� server �Ϊ��C
	// �^�ǭȡA�n�� freeaddrinfo�C�_�h�|�y���O����ݯd�C
	inline addrinfo* easyGetAddrInfo(int port, const addrinfo* hints) {
		return easyGetAddrInfo("", port, hints);
	}
	// ��X�ҥ~�ɡA�O�o�n�� easyGetAddrinfo ���ͪ� free ��
	inline SOCKET easySocket(const addrinfo* info) {
		auto ListenSocket = socket(info->ai_family, info->ai_socktype, info->ai_protocol);
		if (ListenSocket == INVALID_SOCKET) {
			auto err = easyGetWSALastErrorString("socket failed.");
			throw std::exception(err.c_str());
		}
		return ListenSocket;
	}
	// ��X�ҥ~�ɡA�O�o�n closesocket �P freeaddrinfo�C
	inline void easyBind(SOCKET socket, const addrinfo* info) {
		// Setup the TCP listening socket
		auto iResult = bind(socket, info->ai_addr, (int)info->ai_addrlen);
		if (iResult == SOCKET_ERROR) {
			auto err = easyGetWSALastErrorString("bind failed.");
			throw std::exception(err.c_str());
		}
	}
	// ���ͨҥ~�ɡA�O�o closesocket
	inline void easyListen(SOCKET socket, int cnt = SOMAXCONN) {
		auto iResult = listen(socket, cnt);
		if (iResult == SOCKET_ERROR) {
			auto err = easyGetWSALastErrorString("listen failed");
			throw std::exception(err.c_str());
		}
	}
	inline SOCKET easyAccept(SOCKET socketListen) {
		auto re = accept(socketListen, NULL, NULL);
		if (re == INVALID_SOCKET) {
			auto err = easyGetWSALastErrorString("accept failed.");
			throw std::exception(err.c_str());
		}
		return re;
	}
	// �Y false, �� socket ���ΤF�A�O�o closesocket
	inline bool easyConnect(SOCKET socket,const addrinfo* ptr) {
		// Connect to server.
		auto iResult = connect(socket, ptr->ai_addr, (int)ptr->ai_addrlen);
		return SOCKET_ERROR != iResult;
	}
	// �i�D���A�n�����F�C�q�`���۴N�O�I�s closesocket
	inline void easyShutdown(SOCKET socketDst) {
		// shutdown the connection since we're done
		auto iResult = shutdown(socketDst, SD_SEND);
		if (iResult == SOCKET_ERROR) {
			auto err = IJN::easyGetWSALastErrorString("shutdown failed with error: ");
			throw std::exception(err.c_str());
		}
	}
}

namespace IJN {
	// socket, bind, listen
	class SocketForServerGenerator {
	public:
		SOCKET main(int port) {
			auto hints = gAddrinfo();
			auto info = easyGetAddrInfo(port, &hints);
			SOCKET socket = INVALID_SOCKET;
			try {
				socket = easySocket(info);
				easyBind(socket, info);
				freeaddrinfo(info);
				easyListen(socket);
			}
			catch (std::exception& ex) {
				if (socket != INVALID_SOCKET) {
					closesocket(socket);
				}
				freeaddrinfo(info);
				throw ex;
			}
			return socket;
		}
	};
	// try connect and return socket
	class SocketForClientGenerator {
	public:
		SOCKET main(std::string dst, int port) {
			bool isServer = false;
			auto hints = gAddrinfo(isServer);
			auto infos = easyGetAddrInfo(dst, port, &hints);
			try
			{
				auto socket = connectAndReturnFirstSuccessfulOrInvalidSocket(infos);
				if (socket == INVALID_SOCKET) {
					throw std::exception("unable to connect to server");
				}

				freeaddrinfo(infos);
				return socket;
			}
			catch (const std::exception& ex)
			{
				// socket ���͡A�i��|�y�� error
				// �Ⱥ� connect ���ѡA�]���� socket ���͹L�{���~
				freeaddrinfo(infos);
				throw ex;
			}
		}
	private:
		SOCKET connectAndReturnFirstSuccessfulOrInvalidSocket(const addrinfo* infos) {
			auto ptr = infos;
			while (true) {
				if (ptr == nullptr) {
					break;
				}

				auto socket = easySocket(ptr);
				assert(socket != INVALID_SOCKET);
				if (easyConnect(socket, ptr)) {
					return socket; // success connect
				}

				closesocket(socket); // connect failure.
				ptr = ptr->ai_next;
			}

			return INVALID_SOCKET;
		}
	};
}