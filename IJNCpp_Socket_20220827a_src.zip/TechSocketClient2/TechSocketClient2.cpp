﻿// TechSocketClient2.cpp : 此檔案包含 'main' 函式。程式會於該處開始執行及結束執行。
//

#include <iostream>
#include "../IJNCpp/easyWinSock2.hpp"
int main()
{
	IJN::easyWSAStartup();
	while (true) {
		try
		{
			auto socket = IJN::SocketForClientGenerator().main("127.0.0.1", 1234);

			std::cout << "success connect server" << "\n";
			char buf[256];
			auto cntBytes = recv(socket, buf, 256, 0);
			buf[cntBytes + 1] = '\0';

			std::cout << "server response: " << buf << "\n";

			IJN::easyShutdown(socket);
			closesocket(socket);

			std::cout << "is try again? (input `y` or `n`):";
			std::string answer = "y";
			std::cin >> answer;
			if (answer == "n" || answer == "N")
				break;
		}
		catch (const std::exception& ex)
		{
			std::cout << ex.what() << "\n" << "is try again? (input `y` or `n`):";
			std::string answer = "y";
			std::cin >> answer;
			if (answer == "n" || answer == "N")
				break;
		}
	}
}
